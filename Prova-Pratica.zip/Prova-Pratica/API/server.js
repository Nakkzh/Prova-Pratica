// Servidor API para Sistema de Controle de Estoque
// Backend em Node.js com MySQL

const express = require("express")
const cors = require("cors")
const { pool, testarConexao } = require("./db-config")
const app = express()
const PORT = 3001

// Middlewares
app.use(cors())
app.use(express.json())

// Testar conexão ao iniciar
testarConexao()

// Endpoint: POST /usuarios - Cadastro de novo usuário
app.post("/usuarios", async (req, res) => {
  const { nome, email, senha } = req.body

  console.log("[v0] Tentando cadastrar usuário:", { nome, email })

  // Validar campos obrigatórios
  if (!nome || !email || !senha) {
    return res.status(400).json({ erro: "Nome, email e senha são obrigatórios" })
  }

  // Validar tamanho da senha
  if (senha.length < 6) {
    return res.status(400).json({ erro: "A senha deve ter no mínimo 6 caracteres" })
  }

  try {
    // Verificar se o email já existe
    const [usuariosExistentes] = await pool.query("SELECT id FROM usuarios WHERE email = ?", [email])

    console.log("[v0] Verificando email existente:", usuariosExistentes.length)

    if (usuariosExistentes.length > 0) {
      return res.status(409).json({ erro: "Este email já está cadastrado" })
    }

    // Inserir novo usuário
    const [resultado] = await pool.query("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)", [
      nome,
      email,
      senha,
    ])

    console.log("[v0] Usuário cadastrado com ID:", resultado.insertId)

    res.status(201).json({
      sucesso: true,
      mensagem: "Usuário cadastrado com sucesso",
      usuario: {
        id: resultado.insertId,
        nome,
        email,
      },
    })
  } catch (erro) {
    console.error("[v0] Erro ao cadastrar usuário:", erro)
    res.status(500).json({ erro: "Erro ao cadastrar usuário: " + erro.message })
  }
})

// Endpoint: POST /login - Autenticação com banco de dados
app.post("/login", async (req, res) => {
  const { identificador, email, senha } = req.body
  const emailLogin = email || identificador

  if (!emailLogin || !senha) {
    return res.status(400).json({ erro: "Email e senha são obrigatórios" })
  }

  try {
    console.log("[v0] Tentando login com email:", emailLogin)

    // Buscar usuário no banco de dados
    const [usuarios] = await pool.query("SELECT id, nome, email FROM usuarios WHERE email = ? AND senha = ?", [
      emailLogin,
      senha,
    ])

    console.log("[v0] Usuários encontrados:", usuarios.length)

    if (usuarios.length === 0) {
      return res.status(401).json({ erro: "Email ou senha inválidos" })
    }

    const usuario = usuarios[0]

    res.json({
      sucesso: true,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
      },
      responsavel: usuario.nome,
      mensagem: `Bem-vindo(a), ${usuario.nome}!`,
    })
  } catch (erro) {
    console.error("Erro no login:", erro)
    res.status(500).json({ erro: "Erro ao processar login" })
  }
})

// Endpoint: POST /produtos - Cadastro de produto
app.post("/produtos", async (req, res) => {
  const { nome, marca, volume, tipoEmbalagem, aplicacao, estoqueInicial, estoqueMinimo } = req.body

  // Validar campos obrigatórios
  if (!nome || !marca || !volume || !tipoEmbalagem || !aplicacao) {
    return res.status(400).json({ erro: "Todos os campos obrigatórios devem ser preenchidos" })
  }

  try {
    // Inserir produto no banco de dados
    const [resultado] = await pool.query(
      `INSERT INTO produtos (nome_produto, marca, volume, tipo_embalagem, aplicacao, estoque, estoque_minimo) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [nome, marca, volume, tipoEmbalagem, aplicacao, estoqueInicial || 0, estoqueMinimo || 0],
    )

    // Buscar produto recém-criado
    const [produtos] = await pool.query("SELECT * FROM produtos WHERE id = ?", [resultado.insertId])
    const produto = produtos[0]

    res.status(201).json({
      sucesso: true,
      mensagem: "Produto cadastrado com sucesso",
      produto: {
        id: produto.id,
        nome: produto.nome_produto,
        marca: produto.marca,
        volume: produto.volume,
        tipoEmbalagem: produto.tipo_embalagem,
        aplicacao: produto.aplicacao,
        estoqueAtual: produto.estoque,
        estoqueMinimo: produto.estoque_minimo,
      },
    })
  } catch (erro) {
    console.error("Erro ao cadastrar produto:", erro)
    res.status(500).json({ erro: "Erro ao cadastrar produto" })
  }
})

// Endpoint: GET /produtos - Listagem com filtros
app.get("/produtos", async (req, res) => {
  const { nome, marca, apenasAbaixoMinimo } = req.query

  try {
    let query = "SELECT * FROM produtos WHERE 1=1"
    const params = []

    // Filtrar por nome
    if (nome) {
      query += " AND nome_produto LIKE ?"
      params.push(`%${nome}%`)
    }

    // Filtrar por marca
    if (marca) {
      query += " AND marca LIKE ?"
      params.push(`%${marca}%`)
    }

    // Filtrar apenas produtos abaixo do mínimo
    if (apenasAbaixoMinimo === "true") {
      query += " AND estoque < estoque_minimo"
    }

    const [produtos] = await pool.query(query, params)

    // Formatar resposta
    const produtosFormatados = produtos.map((p) => ({
      id: p.id,
      nome: p.nome_produto,
      marca: p.marca,
      volume: p.volume,
      tipoEmbalagem: p.tipo_embalagem,
      aplicacao: p.aplicacao,
      estoqueAtual: p.estoque,
      estoqueMinimo: p.estoque_minimo,
    }))

    res.json({
      sucesso: true,
      total: produtosFormatados.length,
      produtos: produtosFormatados,
    })
  } catch (erro) {
    console.error("Erro ao listar produtos:", erro)
    res.status(500).json({ erro: "Erro ao listar produtos" })
  }
})

// Endpoint: GET /produtos/:id - Detalhes de produto
app.get("/produtos/:id", async (req, res) => {
  const id = Number.parseInt(req.params.id)

  try {
    const [produtos] = await pool.query("SELECT * FROM produtos WHERE id = ?", [id])

    if (produtos.length === 0) {
      return res.status(404).json({ erro: "Produto não encontrado" })
    }

    const p = produtos[0]

    res.json({
      sucesso: true,
      produto: {
        id: p.id,
        nome: p.nome_produto,
        marca: p.marca,
        volume: p.volume,
        tipoEmbalagem: p.tipo_embalagem,
        aplicacao: p.aplicacao,
        estoqueAtual: p.estoque,
        estoqueMinimo: p.estoque_minimo,
      },
    })
  } catch (erro) {
    console.error("Erro ao buscar produto:", erro)
    res.status(500).json({ erro: "Erro ao buscar produto" })
  }
})

// Endpoint: PUT /estoque/entrada - Registrar entrada
app.put("/estoque/entrada", async (req, res) => {
  const { produtoId, quantidade, responsavel, observacao } = req.body

  if (!produtoId || !quantidade || !responsavel) {
    return res.status(400).json({
      erro: "produtoId, quantidade e responsavel são obrigatórios",
    })
  }

  const qtd = Number.parseInt(quantidade)
  if (qtd <= 0) {
    return res.status(400).json({ erro: "Quantidade deve ser maior que zero" })
  }

  const connection = await pool.getConnection()

  try {
    await connection.beginTransaction()

    // Buscar produto
    const [produtos] = await connection.query("SELECT * FROM produtos WHERE id = ?", [produtoId])

    if (produtos.length === 0) {
      await connection.rollback()
      return res.status(404).json({ erro: "Produto não encontrado" })
    }

    const produto = produtos[0]
    const estoqueAnterior = produto.estoque
    const novoEstoque = estoqueAnterior + qtd

    // Atualizar estoque
    await connection.query("UPDATE produtos SET estoque = ? WHERE id = ?", [novoEstoque, produtoId])

    // Buscar ID do usuário
    const [usuarios] = await connection.query("SELECT id FROM usuarios WHERE nome = ?", [responsavel])
    const usuarioId = usuarios.length > 0 ? usuarios[0].id : null

    // Registrar movimentação
    await connection.query(
      `INSERT INTO movimentações (produto_id, usuarios_id, tipo, quantidade) 
       VALUES (?, ?, 'Entrada', ?)`,
      [produtoId, usuarioId, qtd],
    )

    await connection.commit()

    res.json({
      sucesso: true,
      mensagem: "Entrada registrada com sucesso",
      produto: {
        id: produto.id,
        nome: produto.nome_produto,
        estoqueAnterior,
        estoqueAtual: novoEstoque,
      },
    })
  } catch (erro) {
    await connection.rollback()
    console.error("Erro ao registrar entrada:", erro)
    res.status(500).json({ erro: "Erro ao registrar entrada" })
  } finally {
    connection.release()
  }
})

// Endpoint: PUT /estoque/saida - Registrar saída
app.put("/estoque/saida", async (req, res) => {
  const { produtoId, quantidade, responsavel, observacao } = req.body

  if (!produtoId || !quantidade || !responsavel) {
    return res.status(400).json({
      erro: "produtoId, quantidade e responsavel são obrigatórios",
    })
  }

  const qtd = Number.parseInt(quantidade)
  if (qtd <= 0) {
    return res.status(400).json({ erro: "Quantidade deve ser maior que zero" })
  }

  const connection = await pool.getConnection()

  try {
    await connection.beginTransaction()

    // Buscar produto
    const [produtos] = await connection.query("SELECT * FROM produtos WHERE id = ?", [produtoId])

    if (produtos.length === 0) {
      await connection.rollback()
      return res.status(404).json({ erro: "Produto não encontrado" })
    }

    const produto = produtos[0]
    const estoqueAnterior = produto.estoque

    if (estoqueAnterior < qtd) {
      await connection.rollback()
      return res.status(400).json({
        erro: `Estoque insuficiente. Disponível: ${estoqueAnterior}`,
      })
    }

    const novoEstoque = estoqueAnterior - qtd

    // Atualizar estoque
    await connection.query("UPDATE produtos SET estoque = ? WHERE id = ?", [novoEstoque, produtoId])

    // Buscar ID do usuário
    const [usuarios] = await connection.query("SELECT id FROM usuarios WHERE nome = ?", [responsavel])
    const usuarioId = usuarios.length > 0 ? usuarios[0].id : null

    // Registrar movimentação
    await connection.query(
      `INSERT INTO movimentações (produto_id, usuarios_id, tipo, quantidade) 
       VALUES (?, ?, 'Saída', ?)`,
      [produtoId, usuarioId, qtd],
    )

    await connection.commit()

    const alerta = novoEstoque < produto.estoque_minimo ? "ATENÇÃO: Estoque abaixo do mínimo!" : null

    res.json({
      sucesso: true,
      mensagem: "Saída registrada com sucesso",
      produto: {
        id: produto.id,
        nome: produto.nome_produto,
        estoqueAnterior,
        estoqueAtual: novoEstoque,
      },
      alerta,
    })
  } catch (erro) {
    await connection.rollback()
    console.error("Erro ao registrar saída:", erro)
    res.status(500).json({ erro: "Erro ao registrar saída" })
  } finally {
    connection.release()
  }
})

// Endpoint: GET /alertas - Produtos abaixo do mínimo
app.get("/alertas", async (req, res) => {
  try {
    const [produtos] = await pool.query("SELECT * FROM produtos WHERE estoque < estoque_minimo")

    const produtosFormatados = produtos.map((p) => ({
      id: p.id,
      nome: p.nome_produto,
      marca: p.marca,
      estoqueAtual: p.estoque,
      estoqueMinimo: p.estoque_minimo,
      diferenca: p.estoque_minimo - p.estoque,
    }))

    res.json({
      sucesso: true,
      total: produtosFormatados.length,
      produtos: produtosFormatados,
    })
  } catch (erro) {
    console.error("Erro ao buscar alertas:", erro)
    res.status(500).json({ erro: "Erro ao buscar alertas" })
  }
})

// Endpoint: GET /movimentacoes - Histórico de movimentações
app.get("/movimentacoes", async (req, res) => {
  const { produtoId, dataInicio, dataFim } = req.query

  try {
    let query = `
      SELECT m.*, p.nome_produto, u.nome as responsavel_nome
      FROM movimentações m
      LEFT JOIN produtos p ON m.produto_id = p.id
      LEFT JOIN usuarios u ON m.usuarios_id = u.id
      WHERE 1=1
    `
    const params = []

    // Filtrar por produto
    if (produtoId) {
      query += " AND m.produto_id = ?"
      params.push(Number.parseInt(produtoId))
    }

    // Filtrar por período
    if (dataInicio) {
      query += " AND m.data_movimentacao >= ?"
      params.push(dataInicio)
    }

    if (dataFim) {
      query += " AND m.data_movimentacao <= ?"
      params.push(dataFim)
    }

    query += " ORDER BY m.data_movimentacao DESC"

    const [movimentacoes] = await pool.query(query, params)

    const movimentacoesFormatadas = movimentacoes.map((m) => ({
      id: m.id,
      tipo: m.tipo.toLowerCase(),
      produtoId: m.produto_id,
      produtoNome: m.nome_produto,
      quantidade: m.quantidade,
      responsavel: m.responsavel_nome || "Desconhecido",
      dataHora: m.data_movimentacao,
    }))

    res.json({
      sucesso: true,
      total: movimentacoesFormatadas.length,
      movimentacoes: movimentacoesFormatadas,
    })
  } catch (erro) {
    console.error("Erro ao buscar movimentações:", erro)
    res.status(500).json({ erro: "Erro ao buscar movimentações" })
  }
})

// Endpoint de teste
app.get("/", (req, res) => {
  res.json({
    mensagem: "API de Controle de Estoque - Sistema funcionando com MySQL",
    endpoints: {
      login: "POST /login",
      produtos: "POST /produtos, GET /produtos, GET /produtos/:id",
      estoque: "PUT /estoque/entrada, PUT /estoque/saida",
      alertas: "GET /alertas",
      movimentacoes: "GET /movimentacoes",
      usuarios: "POST /usuarios",
    },
  })
})

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`)
  console.log(`📦 API de Controle de Estoque iniciada`)
  console.log(`🔗 Acesse: http://localhost:${PORT}`)
})
