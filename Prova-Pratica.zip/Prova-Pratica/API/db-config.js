// Configuração do Banco de Dados MySQL
const mysql = require("mysql2/promise")

// IMPORTANTE: Configure aqui as credenciais do seu banco de dados
const dbConfig = {
  host: "localhost",
  user: "root",
  password: "",
  database: "estoque",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
}

// Criar pool de conexões
const pool = mysql.createPool(dbConfig)

// Testar conexão
async function testarConexao() {
  try {
    const connection = await pool.getConnection()
    console.log("Conexão com MySQL estabelecida com sucesso!")
    connection.release()
    return true
  } catch (erro) {
    console.error("Erro ao conectar com MySQL:", erro.message)
    console.error("   Verifique se o MySQL está rodando e as credenciais estão corretas")
    return false
  }
}

module.exports = { pool, testarConexao }
